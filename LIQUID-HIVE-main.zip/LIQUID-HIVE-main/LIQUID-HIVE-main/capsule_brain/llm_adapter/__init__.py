"""LLM adapter modules."""
