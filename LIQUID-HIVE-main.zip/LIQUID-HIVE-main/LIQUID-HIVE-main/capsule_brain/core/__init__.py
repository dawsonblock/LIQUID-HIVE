"""Core cognitive architecture components."""
